import hashlib
import json
import logging
import os.path
import re
from io import BytesIO
import time
import mitmproxy.flow
import tornado.escape
import tornado.web
import tornado.websocket
from mitmproxy import contentviews
from mitmproxy import exceptions
from mitmproxy import flowfilter
from mitmproxy import http
from mitmproxy import io
from mitmproxy import log
from mitmproxy import version
from mitmproxy import optmanager
from mitmproxy.tools.cmdline import CONFIG_PATH
import mitmproxy.tools.web.master # noqa
import webServer
from threading import Thread

whiteList = [ "www.google.com.vn",
	"lh3.googleusercontent.com",
	"ssl.google-analytics.com",
	]

logs = {}

class CapAllRequests:
	def __init__(self):
		self.num = 0
		self.recvLogServer = webServer.WebServer(1, 6683)
		worker = Thread(target=self.recvLog, args=())
		worker.setDaemon(False)
		worker.start()

		#worker2 = Thread(target=self.processData, args=())
		#worker2.setDaemon(False)
		#worker2.start()

	def recvLog(self):
		self.recvLogServer.run()

	def processData(self):
		while (True):
			originHeader = self.recvLogServer.deQueueM()
			if originHeader != None:
				#jMR = json.loads(originHeader)
				#print (originHeader)
				modifyR = logs.get(originHeader[-1]["value"], None)
				if modifyR != None:
					modifyHeader = json.loads(modifyR)["Headers"]
					#for index in range(len(originHeader)):
					print (originHeader)
					print ("----------------------")
					print (modifyHeader)

				else:
					self.recvLogServer.enQueueM(originHeader)
			time.sleep(1)

	#xu ly request cua extension
	#chi xu ly neu request send data to server
	#check neu la new form request thi add vao DataF
	#neu da ton tai form thi so sanh Data de xu ly
	#neu len(param) > 5 va param do != voi param trong form mau thi show user
	def checkNewForm(self, f: dict) -> int:
		dataF = self.recvLogServer.getDataF()
		strPath = f["Request-Line"]["method"] + " " +f["Path"]
		flagN = dataF.get(strPath, None)
		if flagN == None:
			f["score"] = {
				"method"	: 10,
				"autoRate"	: 30,
				"urlRate"	: 20,
				"dataRate"	: 50,
				"total"		: 100,
				"block"		: False,
				"description": None,
			}
			self.recvLogServer.addDataF(strPath, f)
			self.recvLogServer.enNewForm(f)
			return 0

		changeData = {}
		changeData["strPath"] = strPath
		changeData["data"] = {}
		if f["Request-Line"]["method"] == "GET" and f["Data"] != None:
			params = f["Data"].items()
			
			for i in range (0, len(f)):
				if len(params[i][1]) > 5 and params[i][1] != flagN["Data"][params[i][0]]:
					changeData["data"][params[i][0]] = param[i][1]

		if f["Request-Line"]["method"] == "POST" and f["Body"] != None:
			if f["Body-Type"] == "URLEncoded form":
				for i in range (0,len(f["Body"])):
					if len(f["Body"][i][1][1]) > 5 and f["Body"][i][1][1] != flagN["Body"][i][1][1]:
						changeData["data"][f["Body"][i][0][1]] = f["Body"][i][1][1]

		if len(changeData["data"]) != 0:
			b = json.dumps(changeData)
			data2 = json.loads(b)
			s = json.dumps(data2, indent=4, sort_keys=True)
			self.recvLogServer.enQueueParam(s)

		return 1




	def request(self, flow):

		hasSign = False
		r = self.convertRequest(flow)
		idR = r["Headers"].get("sign", None)
		if idR != None:
			hasSign = True
			r["idTemp"] = idR

		#cv to json
		b = json.dumps(r)
		data2 = json.loads(b)
		s = json.dumps(data2, indent=4, sort_keys=True)
		#check sign
		if not hasSign:
			if not self.onWhiteList(flow.request.host):
				self.checkNewForm(r)
				#print (flow.request.host)
				self.recvLogServer.enQueueE(s)

		logs[r["id"]] = r
		#print (logs)

	def onWhiteList(self, host) -> bool:
		#print (host)
		for index in range(len(whiteList)):
			if host == whiteList[index] \
			or host.endswith(".google.com") \
			or host.endswith(".gstatic.com"):
				#print ("in whiteList")
				#print (host)
				return True
		return False

	def convertRequest(self, flow: mitmproxy.flow.Flow) -> dict:
		f = {}
		
		f["id"] = flow.id
		f["Host"] = flow.request.host
		f["Path"] = flow.request.url.split("?")[0]
		print (f["Path"])
		f["Request-Line"] = {
			"method" : flow.request.method,
			"url"	 : flow.request.url,
			"http_version": flow.request.http_version,
		}
		f["Headers"] = dict(flow.request.headers.items(True))
		f["Data"] = None
		f["Body"] = None
		if flow.request.method == "GET":
			temp = flow.request.path.split("?")
			if len(temp) >= 2:
				f["Data"] = {}
				temp = flow.request.path.split("?")[1].split("&")
				for i in range(0, len(temp)):
					ct = temp[i].split("=")
					f["Data"][ct[0]] = ct[1]
				

		if flow.request.content:
			content_view = "Auto"
			description, lines, error = contentviews.get_message_content_view(
            content_view, flow.request)

			f["Body"] = list(lines)
			#print (f["Body"][0][1][1])
			f["Body-Type"] = "raw"
			if description != "Couldn't parse: falling back to Raw":
				f["Body-Type"] = description

		#f["RawRequest"] = flow.request

		return f

	def flow_to_json(self, flow: mitmproxy.flow.Flow) -> dict:
		"""
		Remove flow message content and cert to save transmission space.

		Args:
			flow: The original flow.
		"""
		f = {
			"id": flow.id,
			"intercepted": flow.intercepted,
			"client_conn": flow.client_conn.get_state(),
			"server_conn": flow.server_conn.get_state(),
			"type": flow.type,
			"modified": flow.modified(),
			"marked": flow.marked,
		}
		# .alpn_proto_negotiated is bytes, we need to decode that.
		for conn in "client_conn", "server_conn":
			if f[conn]["alpn_proto_negotiated"] is None:
				continue
			f[conn]["alpn_proto_negotiated"] = \
				f[conn]["alpn_proto_negotiated"].decode(errors="backslashreplace")
		# There are some bytes in here as well, let's skip it until we have them in the UI.
		f["client_conn"].pop("tls_extensions", None)
		if flow.error:
			f["error"] = flow.error.get_state()

		if isinstance(flow, http.HTTPFlow):
			if flow.request:
				if flow.request.raw_content:
					content_length = len(flow.request.raw_content)
					content_hash = hashlib.sha256(flow.request.raw_content).hexdigest()
				else:
					content_length = None
					content_hash = None
				f["request"] = {
					"method": flow.request.method,
					"scheme": flow.request.scheme,
					"host": flow.request.host,
					"port": flow.request.port,
					"path": flow.request.path,
					"http_version": flow.request.http_version,
					"headers": tuple(flow.request.headers.items(True)),
					"contentLength": content_length,
					"contentHash": content_hash,
					"timestamp_start": flow.request.timestamp_start,
					"timestamp_end": flow.request.timestamp_end,
					"is_replay": flow.request.is_replay,
					"pretty_host": flow.request.pretty_host,
				}
			if flow.response:
				if flow.response.raw_content:
					content_length = len(flow.response.raw_content)
					content_hash = hashlib.sha256(flow.response.raw_content).hexdigest()
				else:
					content_length = None
					content_hash = None
				f["response"] = {
					"http_version": flow.response.http_version,
					"status_code": flow.response.status_code,
					"reason": flow.response.reason,
					"headers": tuple(flow.response.headers.items(True)),
					"contentLength": content_length,
					"contentHash": content_hash,
					"timestamp_start": flow.response.timestamp_start,
					"timestamp_end": flow.response.timestamp_end,
					"is_replay": flow.response.is_replay,
				}
		f.get("server_conn", {}).pop("cert", None)
		f.get("client_conn", {}).pop("mitmcert", None)

		return f


addons = [CapAllRequests()]

