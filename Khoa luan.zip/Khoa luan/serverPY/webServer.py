import os.path
import tornado.ioloop
import tornado.web
import webbrowser
import time
import json
from threading import Thread
from queue import Queue

data = {
   'url' : 'www.temp123.com',
   'method' : 'GET',
   'number' : 0
}

#request of extension
dataE = Queue()
#new format request
dataF = {}
#new form request
newForm = Queue()
#data send queue()
dataParam = Queue()
#modify request
dataM = Queue()
#cancel request
dataC = Queue()
#rede request
dataR = Queue()

count = 0

def calcScore(items: dict) -> int:
	return items["method"] + items["autoRate"] + items["urlRate"] + items["dataRate"]

#show all request from extension
class ShowLog(tornado.web.RequestHandler):

	def get(self):
		global dataE
		if not dataE.empty():
			self.write(dataE.get())
			#dataE.task_done()
			self.finish()

#get: show newform Data send by extension
#post: return user rate score
class UserRate(tornado.web.RequestHandler):
	
	def get(self):
		global newForm
		if not newForm.empty():
			self.write(newForm.get())
			self.finish()

	def post(self):
		data = self.request.body.decode('utf8')
		data2 = json.loads(data)
		f = dataF[data2["strPath"]]
		f["score"]["urlRate"] = data2["urlRate"]
		f["score"]["dataRate"] = data2["dataRate"]
		totalScore = calcScore(f["score"])
		f["score"]["total"] = totalScore
		if totalScore < 50:
			f["score"]["block"] = True
		print (totalScore)
		#print (type(data2))

		
		
#render web UI
class MainHandler(tornado.web.RequestHandler):

	def get(self):
		self.render('index.html')

#recv modify request from extension
class RecvMR(tornado.web.RequestHandler):

	def get(self):
		global dataM
		if not dataM.empty():
			self.write(dataM.get())
			self.finish()

	def post(self):
		self.write(json.dumps({'status': 'ok'}))
		self.finish()
		self.enQueue(self.request.body)

	#convert log from byte -> json
	#add log to queue
	def enQueue(self, rawData: bytes):
		global dataM
		data = rawData.decode('utf8')
		data2 = json.loads(data)
		s = json.dumps(data2, indent=4, sort_keys=True)
		dataM.put(data2)
		#print(s)

#recv cancel request from extension
class RecvCR(tornado.web.RequestHandler):

	def get(self):
		print ("trigger")
		self.write("da nhan")
		self.finish()

	def post(self):
		self.write(json.dumps({'status': 'ok'}))
		self.finish()
		self.enQueue(self.request.body)

	#convert log from byte -> json
	#add log to queue
	def enQueue(self, rawData: bytes):
		global dataE
		data = rawData.decode('utf8')
		data2 = json.loads(data)
		#s = json.dumps(data2, indent=4, sort_keys=True)
		dataC.put(data2)
		#print(s)
		

		
#khoi tao server cho web hien thi log
class WebServer():
	#cau hinh Handle = MainHandle
	#cau hinh Port = 8888
	def __init__(self, option: str, port: str):
		self.option = option
		self.port = port
		ws  = tornado.web.Application([
			(r"/", MainHandler),
			(r"/ShowLog", ShowLog),
			(r"/RecvCR", RecvCR),
			(r"/UserRate", UserRate),
			(r"/RecvMR", RecvMR)],
			static_path = os.path.join(os.path.dirname(__file__), "static"),
			template_path = os.path.join(os.path.dirname(__file__), "templates"))

		self.http_server = tornado.httpserver.HTTPServer(ws)
		self.web_url = "http://localhost:{}/".format(self.port)
		self.http_server.listen(self.port)

	#tao loop - start server
	def run(self):
		print ("Web server on: ")
		print (self.web_url)

		#auto open web UI
		success = self.open_browser(self.web_url)
		if not success:
			print ("Erro: cant open {} on your browser".format(self.web_url))
				
		try:
			tornado.ioloop.IOLoop.instance().start()
		except KeyboardInterrupt:
			self.shutdown()

	#shutdown Server
	def shutdown(self):
		tornado.ioloop.IOLoop.instance().stop()

	#Open a URL in a browser window.
	def open_browser(self, url: str) -> bool:
	
		browsers = (
			"windows-default", "macosx",
		 "google-chrome", "chrome", "chromium", "chromium-browser",
		 "firefox", "opera", "safari",
		)
		for browser in browsers:
			try:
				b = webbrowser.get(browser)
			except webbrowser.Error:
				pass
			else:
				b.open(url)
				return True
		return False

	def enQueueE(self, requestF: dict):
		global dataE
		dataE.put(requestF)
		#dataE.task_done()


	def deQueue(self):
		global dataE
		if not dataE.empty():
			print (dataE.get())
			#dataE.task_done()

	def deQueueM(self) -> list:
		global dataM
		if not dataM.empty():
			print ("---------------------------------------------------------")
			return dataM.get() 
		return None

	def enQueueM(self, requestM: list):
		global dataM
		dataM.put(requestM)

	def getDataF(self) -> dict:
		global dataF
		return dataF

	def addDataF(self, url: str, data: dict):
		global dataF
		dataF[url] = data

	def enQueueParam(self, data: dict):
		global dataParam
		dataParam.put(data)

	def	enNewForm(self, f: dict)
		global newForm
		newForm.put(f)



#if __name__ == "__main__":
#	main = WebServer()
#	main.run()