function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

//GET new log from server by json
async function getNewLog() {
    var xmlhttp = new XMLHttpRequest();
    while (true) {
    	xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            showLog(this.responseText);
        	}
   		};
    	xmlhttp.open("GET", "ShowLog", true);
    	xmlhttp.send();
    	//showLog(this.responseText);
    	await sleep(500);
    }
}

//GET new log from server by json
async function testSendData() {
    var jsonObj = {};
    jsonObj["strPath"] = "POST abc.com";
    jsonObj["urlRate"] = "10";
    jsonObj["dataRate"] = "25";
    
    var a = JSON.stringify(jsonObj);
    console.log("maclious Extension started");
    var xmlhttp = new XMLHttpRequest();
    while (true) {
        console.log("done");
        //xmlhttp.open("GET", "https://facebook.com/", true);
        //xmlhttp.send();

        xmlhttp.open("POST", "http://localhost:6683/UserRate", true);
        xmlhttp.send(a);
        //showLog(this.responseText);
        await sleep(2000);
    }
}


//show log in table
function showLog(newLog) {
    //var obj = JSON.parse(newLog);
    //var para = document.createElement("p");
	//var node = document.createTextNode(obj.url + " " + obj.number);
	//para.appendChild(node);
	//var element = document.getElementById("content");
	//element.appendChild(para);
    if (newLog.length > 0) {
        console.log("------------------------------------------------------------------------------------")
        var obj = JSON.parse(newLog);
        //console.log(obj["Request-Line"].method);
        //console.log(obj["Request-Line"]);
        //console.log(obj.Headers);
        console.log(obj);
        console.log(obj.data);
        console.log(obj.strPath)
    }
}


window.onload = function main(){
	testSendData();
}
