/* test.js */
var test3 = ""

function set_test(val)
{
    test3=val
}

function show_test()
{
    alert(test3);
}