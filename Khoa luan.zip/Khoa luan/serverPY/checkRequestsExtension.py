import requests
import json
 
APIkey = "AIzaSyDQCh0f0ooHPXPvzR1naaCQdswgIXnOI4k"

url = 'https://safebrowsing.googleapis.com/v4/threatMatches:find?key=AIzaSyDQCh0f0ooHPXPvzR1naaCQdswgIXnOI4k'
headers = {'Content-Type': 'application/json'}
body = {}

#body["client"] = {
#	      "clientId":      "checkRequestsExtension",
#	      "clientVersion": "1.0"
#	    }

#body["threatInfo"] = {
#	      "threatTypes":      ["THREAT_TYPE_UNSPECIFIED"],
#	      "platformTypes":    ["WINDOWS"],
#	      "threatEntryTypes": ["URL"],
#	      "threatEntries": [
#	        {"url": "http://www.urltocheck1.org/"}
#	      ]
#	  }
body = {
    "client": {
      "clientId":      "yourcompanyname",
      "clientVersion": "1.5.2"
    },
    "threatInfo": {
      "threatTypes":      ["THREAT_TYPE_UNSPECIFIED", "MALWARE", "SOCIAL_ENGINEERING", "UNWANTED_SOFTWARE", "POTENTIALLY_HARMFUL_APPLICATION"],
      "platformTypes":    ["WINDOWS", "CHROME"],
      "threatEntryTypes": ["URL"],
      "threatEntries": [
        {"url": "http://consulfrance-istanbul.org:80"}
      ]
    }
  }

#print (json.dumps(body))
req = requests.post(url, headers=headers, data=json.dumps(body))
print (req.json())