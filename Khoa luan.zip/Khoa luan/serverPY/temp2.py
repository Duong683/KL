import webServer
import time
from threading import Thread

def recvLog(recvLogServer):
	recvLogServer.run()

recvLogServer = webServer.WebServer(2, 6683)

worker = Thread(target=recvLog, args=(recvLogServer,))
worker.setDaemon(False)
worker.start()
while True:
	recvLogServer.deQueue()