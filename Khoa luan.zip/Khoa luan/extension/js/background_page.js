//TODO:
//chrome.management.get("fhbjgbiflinjbdggehcddcbncdddomop", function(a) {console.log(a)})
//chrome.management.launchApp("fhbjgbiflinjbdggehcddcbncdddomop", function(a) {console.log(a)}) to open the app

var blacklistedIds = ["none"],

	// enum for postman message types
	postmanMessageTypes = {
	  xhrError: "xhrError",
	  xhrResponse: "xhrResponse",
	  captureStatus: "captureStatus",
	  capturedRequest: "capturedRequest"
	},

	// indicates status of popup connected
	popupConnected = false,

	// placeholder for the background page port object for transferring log msgs
	BackgroundPort,

	//store onBeforeRequest
	requestCache = {},

	//store origin requestHeaders
	requestCacheHeader = {},

	xmlhttp = new XMLHttpRequest(),

	// storing last N (maxItems) log messages
	maxItems = 10,
	logCache = new Deque(maxItems),

	background = this,

	// Options which are shared with Extension Popup.
	appOptions = {
		isCaptureStateEnabled: false,
		filterRequestUrl: '.*'
	},

	// requestId is a chrome-specific value that we get in the onBeforeSendHeaders handler
	// postman-interceptor-token is a header (X-Postman-Interceptor-Id) that we add in the interceptor code
	requestTokenMap = {}, // map from postman-interceptor-token to postmanMessage and requestId.
	requestIdMap = {}, // map from requestId to postmanMessage and postman-interceptor-token.
	CUSTOM_INTERCEPTOR_HEADER = "X-Postman-Interceptor-Id",

	restrictedChromeHeaders = [
	    "ACCEPT-CHARSET",
	    "ACCEPT-ENCODING",
	    "ACCESS-CONTROL-REQUEST-HEADERS",
	    "ACCESS-CONTROL-REQUEST-METHOD",
	    "CONTENT-LENGTHNECTION",
	    "CONTENT-LENGTH",
	    "COOKIE",
	    "CONTENT-TRANSFER-ENCODING",
	    "DATE",
	    "EXPECT",
	    "HOST",
	    "KEEP-ALIVE",
	    "ORIGIN",
	    "REFERER",
	    "TE",
	    "TRAILER",
	    "TRANSFER-ENCODING",
	    "UPGRADE",
	    "USER-AGENT",
	    "VIA"
	];

// filters requests before sending it to postman
function filterCapturedRequest(request) {
    var patt = new RegExp(appOptions.filterRequestUrl, "gi");
    var validRequestTypes = ["xmlhttprequest", "main_frame", "sub_frame"];
    return (_.contains(validRequestTypes, request.type) && request.url.match(patt))
}

function filterRequest(request) {
    if (request.url.match("http://localhost:6683/")) {
    	return false;
    }
    return true;
}

//add requestHeader original to requestCacheHeader
//add sign to requestHeaders
//sign = {
//		"name" : sign
//		"value": requestID
//} 
function onBeforeSendHeaders(details) {
	if (filterRequest(details)) {
		//console.log(details);
		requestCacheHeader[details.requestId] = details.requestHeaders;
		//requestCacheHeader[details.requestId].push({"name" : "sign", "value" : details.requestId});
		details.requestHeaders.push({"name" : "sign", "value" : details.requestId});
		return { requestHeaders: details.requestHeaders };
  }
}

//store requestID to check request cancer
function onBeforeRequest(details) {
	if (filterRequest(details)) {
		requestCache[details.requestId] = details;
		//console.log(details);
	}
}

//add requestHeader final version to requestCache
//
function onSendHeaders(details) {
	if (filterRequest(details)) {
		if (requestCache.hasOwnProperty(details.requestId)) { 
			if (md5(requestCacheHeader[details.requestId]) != md5(details.requestHeaders)){
				//modify request
				console.log("---------------");
				console.log("requestHeaders modify:" + details.requestId);
				var jsonObj = {};
				jsonObj["id"] = details.requestId;
				jsonObj["originalHeader"] = requestCacheHeader[details.requestId];
				jsonObj["modifyHeader"] = details.requestHeaders;
				delete requestCacheHeader[details.requestId];
  				delete requestCache[details.requestId];
				sendModifyRequestsToServer(JSON.stringify(jsonObj));
			//}
			//console.log(details);
			//sendCapturedRequestToServer(details.requestId);
		}
		else {
			//request cancel
		}
	}
	}
}

// sends the captured request to server
// then clears the cache
function sendCapturedRequestToServer(reqId){
  xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status !== 200) {
        console.log("Erro: send log erro");
        sendCapturedRequestToServer(reqId);
        }	
	};

  //console.log(requestCache[reqId]);
  xmlhttp.open("POST", "http://localhost:6683/", true);
  xmlhttp.send(JSON.stringify(requestCache[reqId]));
}

function sendModifyRequestsToServer(jsonObj){
  xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
  	console.log(this.responseText);
  }
  else if (this.readyState == 4 && this.status !== 200) {
  	//resend log
  	console.log("Erro: send log erro");
    sendModifyRequestsToServer(jsonObj);
  }};
  xmlhttp.open("POST", "http://localhost:6683/RecvMR", true);
  xmlhttp.send(jsonObj);
}

/*
// long-lived connection to the popupchannel (as popup is opened)
// notifies when popup can start listening
chrome.runtime.onConnect.addListener(function(port){
  console.assert(port.name === 'POPUPCHANNEL');
  BackgroundPort = chrome.runtime.connect({name: 'BACKGROUNDCHANNEL'});
  popupConnected = true;

  port.onMessage.addListener(function(msg) {
    if (msg.options) {
      appOptions.isCaptureStateEnabled = msg.options.toggleSwitchState;
    }
    if(msg.reset) {
        logCache.clear();
    }
  });

  BackgroundPort.postMessage({options: appOptions});
  BackgroundPort.postMessage({logcache: logCache});
  console.log("Sending isPostman Open: " , isPostmanOpen);
  BackgroundPort.postMessage({isPostmanOpen: isPostmanOpen});

  // when the popup has been turned off - no longer send messages
  port.onDisconnect.addListener(function(){
    popupConnected = false;
  });

});*/

// adds an event listener to the onBeforeSendHeaders
chrome.webRequest.onBeforeSendHeaders.addListener(onBeforeSendHeaders,
	{ urls: ["<all_urls>"] },
	[ "blocking", "requestHeaders"]
);


// event listener called for each request to intercept - used to intercept request data
chrome.webRequest.onBeforeRequest.addListener(onBeforeRequest, 
    { urls: ["<all_urls>"] }, 
    [ "requestBody" ]
);

//event listener called just before sending - used for getting headers
chrome.webRequest.onSendHeaders.addListener(onSendHeaders, 
    { urls: ["<all_urls>"] }, 
    [ "requestHeaders" ]
);
