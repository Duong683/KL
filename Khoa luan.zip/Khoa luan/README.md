"detect malicious browser extension" 
